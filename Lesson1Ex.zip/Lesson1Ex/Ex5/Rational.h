#pragma once
#include <iostream>
using namespace std;

class Rational
{
	//private:
	int numerator;
	int denominator;
public:
	//constructor
	Rational(int num, int denom);
	void print(); 


};
